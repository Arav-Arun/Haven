import{o as e,p as o,A as r}from"./App-CO8eVeee.js";try{}catch(t){console.error("[wxt] Failed to initialize plugins",t)}e.createRoot(document.getElementById("root")).render(o.jsx(r,{}));
